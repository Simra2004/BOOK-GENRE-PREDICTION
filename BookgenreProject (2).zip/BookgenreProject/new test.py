import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import tkinter as tk
from tkinter import ttk, scrolledtext
import pickle
from sklearn.svm import SVC

# Load data
df = pd.read_csv('data.csv')

def preprocess_and_train(df):
    # Encode genres as numerical labels
    label_encoder = LabelEncoder()
    df['genre_encoded'] = label_encoder.fit_transform(df['genre'])

    # Text vectorization using TF-IDF
    vectorizer = TfidfVectorizer(max_features=1000)
    X = vectorizer.fit_transform(df['summary']).toarray()
    y = df['genre_encoded']
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    # Train the SVC model
    svm_model = SVC()
    svm_model.fit(X_train, y_train)

    # Save model, vectorizer, and label encoder
    with open('book_genre_classifier.pkl', 'wb') as f:
        pickle.dump((svm_model, vectorizer, label_encoder), f)

    print("Model and other objects have been saved successfully.")

# Function to make predictions
def predict_genre(description):
    vectorized_desc = vectorizer.transform([description])
    genre_encoded = model.predict(vectorized_desc)
    genre = encoder.inverse_transform(genre_encoded)[0]
    result_label.config(text=f'Predicted Genre: {genre}')

# Load the model and other objects
def load_model():
    global model, vectorizer, encoder
    with open('book_genre_classifier.pkl', 'rb') as f:
        model, vectorizer, encoder = pickle.load(f)

# Create the GUI
def create_gui():
    global result_label, listbox

    root = tk.Tk()
    root.title("Book Genre Classifier")
    root.geometry("1000x700")
    root.configure(bg='#e0f7fa')

    style = ttk.Style()
    style.configure('TLabel', font=('Helvetica', 14), background='#e0f7fa')
    style.configure('TButton', font=('Helvetica', 10, 'bold'), background='#00796b', foreground='white')
    style.configure('TEntry', font=('Helvetica', 12))
    style.configure('TListbox', font=('Helvetica', 12))

    is_light_theme = True

    def toggle_color():
        nonlocal is_light_theme
        if is_light_theme:
            root.configure(bg='#263238')
            style.configure('TLabel', background='#263238', foreground='#ffffff')
            style.configure('TButton', background='#455a64', foreground='#ffffff')
            text_entry.configure(background='#37474f', foreground='#ffffff')
        else:
            root.configure(bg='#e0f7fa')
            style.configure('TLabel', background='#e0f7fa', foreground='#000000')
            style.configure('TButton', background='#00796b', foreground='#ffffff')
            text_entry.configure(background='#ffffff', foreground='#000000')
        is_light_theme = not is_light_theme

    color_button = ttk.Button(root, text="Toggle Color", command=toggle_color)
    color_button.pack(pady=10)

    # Alphabet filter
    alphabet_frame = ttk.Frame(root)
    alphabet_frame.pack(pady=10)

    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        btn = tk.Button(alphabet_frame, text=letter, command=lambda l=letter: filter_books_by_letter(l), width=3, bg='#00796b', fg='white')
        btn.pack(side=tk.LEFT, padx=2, pady=5)

    # Search feature
    search_var = tk.StringVar()
    search_var.trace("w", lambda *args: update_list(search_var.get()))

    search_label = ttk.Label(root, text="Search Book:")
    search_label.pack(pady=10)

    search_entry = ttk.Entry(root, textvariable=search_var, width=50)
    search_entry.pack(pady=10)

    # Sorting options
    sort_label = ttk.Label(root, text="Sort Books By:")
    sort_label.pack(pady=10)

    sort_var = tk.StringVar(value="title")
    sort_combobox = ttk.Combobox(root, textvariable=sort_var, values=["title"], state="readonly")
    sort_combobox.pack(pady=10)
    sort_combobox.bind("<<ComboboxSelected>>", lambda event: sort_books(sort_var.get()))

    listbox = tk.Listbox(root, width=60, height=10, font=('Helvetica', 12))
    listbox.pack(pady=10)
    listbox.bind("<<ListboxSelect>>", lambda event: on_select(event, listbox))

    text_entry = scrolledtext.ScrolledText(root, height=8, width=80, font=('Helvetica', 12))
    text_entry.pack(pady=10)

    result_label = ttk.Label(root, text="Predicted Genre: ", font=('Helvetica', 14, 'bold'))
    result_label.pack(pady=10)

    # Populate the listbox with titles
    for title in df['title']:
        listbox.insert(tk.END, title)

    def update_list(search_term):
        filtered_titles = df[df['title'].str.contains(search_term, case=False, na=False)]['title']
        listbox.delete(0, tk.END)
        for title in filtered_titles:
            listbox.insert(tk.END, title)

    def on_select(event, listbox):
        try:
            index = listbox.curselection()[0]
            selected_title = listbox.get(index)  # Extract title from the listbox entry
            book_data = df[df['title'] == selected_title].iloc[0]
            description = book_data['summary']
            text_entry.delete('1.0', tk.END)
            text_entry.insert(tk.END, description)
            predict_genre(description)
        except IndexError:
            pass

    def sort_books(criteria):
        sorted_df = df.sort_values(by=criteria, ascending=True)
        listbox.delete(0, tk.END)
        for title in sorted_df['title']:
            listbox.insert(tk.END, title)

    def filter_books_by_letter(letter):
        filtered_titles = df[df['title'].str.startswith(letter)]['title']
        listbox.delete(0, tk.END)
        for title in filtered_titles:
            listbox.insert(tk.END, title)

    root.mainloop()


# Main function to control flow of application
def main():
    preprocess_and_train(df)  # Uncomment this line to train and save the model once
    load_model()
    create_gui()


if __name__ == "__main__":
    main()
